//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� GameServer.rc ʹ��
//
#define IDR_MAINFRAME                   128
#define IDD_CUSTOM_RULE                 6000
#define IDC_TIME_OUT_CARD               6001
#define IDC_TIME_WAIT_END               6002
#define IDC_TIME_OPERATE_CARD           6003
#define IDC_TIME_START_GAME             6004
#define IDC_EDIT_TRUSTEEDELAY_TIME      6005
#define IDC_CHECK_HUANSANZHANG          6020
#define IDC_CHECK_HUJIAOZHUANYI         6021
#define IDC_CHECK_ZIMOADDTIMES          6022
#define IDC_CHECK_TIANDIHU              6023
#define IDC_CHECK_HAIDILAOYUE           6024
#define IDC_CHECK_MENQING               6025
#define IDD_PERSONAL_RULE               6050
#define IDC_EDIT5                       6051
#define IDC_EDIT1                       6052
#define IDC_EDIT2                       6053
#define IDC_EDIT3                       6054
#define IDC_EDIT4                       6055
#define IDC_EDIT6                       6056
#define IDC_TIME_START_GAME5            6057
#define IDC_TIME_START_GAME6            6058
#define IDC_TIME_START_GAME7            6059
#define IDC_TIME_START_GAME8            6060
#define IDC_TIME_START_GAME9            6061
#define IDC_TIME_START_GAME10           6062
#define IDC_TIME_START_GAME11           6063
#define IDC_TIME_START_GAME12           6064
#define IDC_TIME_START_GAME13           6065
#define IDC_TIME_START_GAME14           6066
#define IDC_TIME_START_GAME15           6067
#define IDC_TIME_START_GAME16           6068
#define IDC_TIME_START_GAME17           6069
#define IDC_TIME_START_GAME18           6070
#define IDC_TIME_START_GAME19           6071
#define IDC_TIME_START_GAME20           6072
#define IDC_TIME_START_GAME21           6073
#define IDC_TIME_START_GAME22           6074
#define IDC_TIME_START_GAME23           6075
#define IDC_TIME_START_GAME24           6076

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        6001
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6028
#define _APS_NEXT_SYMED_VALUE           6000
#endif
#endif
